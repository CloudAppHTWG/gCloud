import { Imagedata } from './ImagedataModel';
export class Image {
  constructor(
    img: Imagedata,
    _id: string,
    name: string,
    desc: string,
    __v: number
  ) {}

  img: Imagedata;
  _id: string;
  name: string;
  desc: string;
  __v: number;
}
