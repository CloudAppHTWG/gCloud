export class Imagedata {
    data: string;
    contentType: string;
}
